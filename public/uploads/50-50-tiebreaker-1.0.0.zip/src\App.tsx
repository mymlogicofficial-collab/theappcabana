import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import RPS from '@/components/RPS';
import CoinFlip from '@/components/CoinFlip';
import DiceRoll from '@/components/DiceRoll';
import PickNumber from '@/components/PickNumber';
import './App.css';

type GameMode = 'menu' | 'rps' | 'coin' | 'dice' | 'number';

export default function App() {
  const [mode, setMode] = useState<GameMode>('menu');
  const [gameHistory, setGameHistory] = useState<string[]>([]);

  const addToHistory = (result: string) => {
    setGameHistory(prev => [result, ...prev].slice(0, 10));
  };

  return (
    <div className="50-50-app min-h-screen bg-gradient-to-br from-indigo-900 via-slate-900 to-purple-900 text-white p-6">
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="text-6xl font-black mb-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
          ⚡ 50/50 TIE BREAKER ⚡
        </h1>
        <p className="text-gray-300 text-lg">Settle it once and for all</p>
      </header>

      <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Game Area */}
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {mode === 'menu' && (
              <motion.div
                key="menu"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <button
                  onClick={() => setMode('rps')}
                  className="game-btn w-full text-2xl p-6 bg-gradient-to-br from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900"
                >
                  ✋ ROCK PAPER SCISSORS
                </button>
                <button
                  onClick={() => setMode('coin')}
                  className="game-btn w-full text-2xl p-6 bg-gradient-to-br from-yellow-600 to-yellow-800 hover:from-yellow-700 hover:to-yellow-900"
                >
                  🪙 COIN FLIP
                </button>
                <button
                  onClick={() => setMode('dice')}
                  className="game-btn w-full text-2xl p-6 bg-gradient-to-br from-red-600 to-red-800 hover:from-red-700 hover:to-red-900"
                >
                  🎲 DICE ROLL
                </button>
                <button
                  onClick={() => setMode('number')}
                  className="game-btn w-full text-2xl p-6 bg-gradient-to-br from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900"
                >
                  🎯 PICK A NUMBER
                </button>
              </motion.div>
            )}

            {mode === 'rps' && (
              <RPS key="rps" onBack={() => setMode('menu')} onResult={addToHistory} />
            )}
            {mode === 'coin' && (
              <CoinFlip key="coin" onBack={() => setMode('menu')} onResult={addToHistory} />
            )}
            {mode === 'dice' && (
              <DiceRoll key="dice" onBack={() => setMode('menu')} onResult={addToHistory} />
            )}
            {mode === 'number' && (
              <PickNumber key="number" onBack={() => setMode('menu')} onResult={addToHistory} />
            )}
          </AnimatePresence>
        </div>

        {/* History Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 h-fit sticky top-20">
            <h3 className="text-lg font-bold mb-4 text-orange-400">📜 Recent Results</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {gameHistory.length > 0 ? (
                gameHistory.map((result, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="text-sm p-2 bg-slate-700/50 rounded border-l-2 border-orange-500 text-gray-200"
                  >
                    {result}
                  </motion.div>
                ))
              ) : (
                <p className="text-gray-400 text-sm italic">No results yet...</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
