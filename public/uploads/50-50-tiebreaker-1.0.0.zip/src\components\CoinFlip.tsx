import { useState } from 'react';
import { motion } from 'framer-motion';

interface CoinFlipProps {
  onBack: () => void;
  onResult: (result: string) => void;
}

type CoinSide = 'heads' | 'tails' | null;

export default function CoinFlip({ onBack, onResult }: CoinFlipProps) {
  const [result, setResult] = useState<CoinSide>(null);
  const [isFlipping, setIsFlipping] = useState(false);

  const flip = () => {
    if (isFlipping) return;
    setIsFlipping(true);
    setResult(null);

    setTimeout(() => {
      const coinResult: CoinSide = Math.random() < 0.5 ? 'heads' : 'tails';
      setResult(coinResult);
      onResult(`Coin: ${coinResult.toUpperCase()}`);
      setIsFlipping(false);
    }, 2000);
  };

  const reset = () => {
    setResult(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-gradient-to-br from-yellow-900/50 to-slate-900/50 border-2 border-yellow-500/50 rounded-2xl p-8 space-y-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">COIN FLIP</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm"
        >
          ← Back
        </button>
      </div>

      <div className="text-center">
        <motion.div
          className="text-9xl my-8"
          animate={isFlipping ? { rotateY: [0, 360] } : {}}
          transition={isFlipping ? { duration: 2, repeat: Infinity } : {}}
        >
          {result ? (result === 'heads' ? '🪙' : '🎫') : '🪙'}
        </motion.div>

        {result && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-4xl font-bold mb-6"
          >
            {result === 'heads' ? '👑 HEADS' : '✍️ TAILS'}
          </motion.div>
        )}

        {!result ? (
          <button
            onClick={flip}
            disabled={isFlipping}
            className="px-8 py-4 bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50 rounded-lg font-bold text-xl"
          >
            🪙 FLIP THE COIN
          </button>
        ) : (
          <button
            onClick={reset}
            className="px-8 py-4 bg-yellow-600 hover:bg-yellow-700 rounded-lg font-bold text-xl"
          >
            Flip Again
          </button>
        )}
      </div>
    </motion.div>
  );
}
