import { useState } from 'react';
import { motion } from 'framer-motion';

interface DiceRollProps {
  onBack: () => void;
  onResult: (result: string) => void;
}

export default function DiceRoll({ onBack, onResult }: DiceRollProps) {
  const [result, setResult] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState(false);

  const DICE_EMOJIS = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

  const roll = () => {
    if (isRolling) return;
    setIsRolling(true);
    setResult(null);

    setTimeout(() => {
      const diceResult = Math.floor(Math.random() * 6) + 1;
      setResult(diceResult);
      onResult(`Dice: ${diceResult}`);
      setIsRolling(false);
    }, 1500);
  };

  const reset = () => {
    setResult(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-gradient-to-br from-red-900/50 to-slate-900/50 border-2 border-red-500/50 rounded-2xl p-8 space-y-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">DICE ROLL</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm"
        >
          ← Back
        </button>
      </div>

      <div className="text-center">
        <motion.div
          className="text-9xl my-8"
          animate={isRolling ? { rotate: [0, 360], scale: [1, 1.2, 1] } : {}}
          transition={isRolling ? { duration: 1.5, repeat: Infinity } : {}}
        >
          {result ? DICE_EMOJIS[result] : '🎲'}
        </motion.div>

        {result && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-6xl font-bold mb-6 text-red-400"
          >
            {result}
          </motion.div>
        )}

        {!result ? (
          <button
            onClick={roll}
            disabled={isRolling}
            className="px-8 py-4 bg-red-600 hover:bg-red-700 disabled:opacity-50 rounded-lg font-bold text-xl"
          >
            🎲 ROLL THE DICE
          </button>
        ) : (
          <button
            onClick={reset}
            className="px-8 py-4 bg-red-600 hover:bg-red-700 rounded-lg font-bold text-xl"
          >
            Roll Again
          </button>
        )}
      </div>
    </motion.div>
  );
}
