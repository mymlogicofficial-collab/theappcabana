import { useState } from 'react';
import { motion } from 'framer-motion';

interface PickNumberProps {
  onBack: () => void;
  onResult: (result: string) => void;
}

export default function PickNumber({ onBack, onResult }: PickNumberProps) {
  const [playerGuess, setPlayerGuess] = useState<string>('');
  const [computerNumber, setComputerNumber] = useState<number | null>(null);
  const [result, setResult] = useState<'close' | 'exact' | 'far' | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const submit = () => {
    const guess = parseInt(playerGuess);
    if (isNaN(guess) || guess < 1 || guess > 100) return;

    const computer = Math.floor(Math.random() * 100) + 1;
    setComputerNumber(computer);

    let gameResult: 'close' | 'exact' | 'far';
    const diff = Math.abs(guess - computer);

    if (diff === 0) {
      gameResult = 'exact';
    } else if (diff <= 10) {
      gameResult = 'close';
    } else {
      gameResult = 'far';
    }

    setResult(gameResult);
    setIsSubmitted(true);
    onResult(`Number: You guessed ${guess}, answer was ${computer} (${gameResult})`);
  };

  const reset = () => {
    setPlayerGuess('');
    setComputerNumber(null);
    setResult(null);
    setIsSubmitted(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-gradient-to-br from-purple-900/50 to-slate-900/50 border-2 border-purple-500/50 rounded-2xl p-8 space-y-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">PICK A NUMBER</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm"
        >
          ← Back
        </button>
      </div>

      {!isSubmitted ? (
        <div className="text-center space-y-6">
          <p className="text-gray-300 text-lg">Pick a number between 1 and 100:</p>
          <input
            type="number"
            value={playerGuess}
            onChange={(e) => setPlayerGuess(e.target.value)}
            min="1"
            max="100"
            placeholder="Your guess..."
            className="w-full text-center text-4xl p-4 bg-slate-800 border-2 border-purple-500 rounded-lg text-white"
          />
          <button
            onClick={submit}
            disabled={!playerGuess}
            className="w-full py-4 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-lg font-bold text-xl"
          >
            🎯 SUBMIT
          </button>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6 text-center"
        >
          <div className="grid grid-cols-2 gap-8">
            <div>
              <p className="text-sm text-gray-400 mb-2">Your Guess</p>
              <motion.div
                className="text-6xl font-bold text-purple-400"
                animate={{ scale: [1, 1.1, 1] }}
              >
                {playerGuess}
              </motion.div>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-2">Answer</p>
              <motion.div
                className="text-6xl font-bold text-orange-400"
                animate={{ scale: [1, 1.1, 1] }}
              >
                {computerNumber}
              </motion.div>
            </div>
          </div>

          <motion.div
            className={`p-6 rounded-xl text-3xl font-bold ${
              result === 'exact'
                ? 'bg-green-900/50 text-green-400'
                : result === 'close'
                ? 'bg-yellow-900/50 text-yellow-400'
                : 'bg-red-900/50 text-red-400'
            }`}
            animate={{ scale: [1, 1.05, 1] }}
          >
            {result === 'exact' ? '🎉 EXACT!' : result === 'close' ? '🔥 CLOSE!' : '❄️ NOPE!'}
          </motion.div>

          <button
            onClick={reset}
            className="w-full py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-bold text-lg"
          >
            Try Again
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}
