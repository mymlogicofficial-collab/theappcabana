import { useState } from 'react';
import { motion } from 'framer-motion';

interface RPSProps {
  onBack: () => void;
  onResult: (result: string) => void;
}

type Choice = 'rock' | 'paper' | 'scissors' | null;
type Result = 'win' | 'lose' | 'tie' | null;

const CHOICES = {
  rock: '✊',
  paper: '✋',
  scissors: '✌️',
};

export default function RPS({ onBack, onResult }: RPSProps) {
  const [playerChoice, setPlayerChoice] = useState<Choice>(null);
  const [computerChoice, setComputerChoice] = useState<Choice>(null);
  const [result, setResult] = useState<Result>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const play = (choice: Choice) => {
    if (isPlaying) return;
    setIsPlaying(true);

    const choices: Choice[] = ['rock', 'paper', 'scissors'];
    const computer = choices[Math.floor(Math.random() * 3)];

    setPlayerChoice(choice);

    setTimeout(() => {
      setComputerChoice(computer);

      let gameResult: Result;
      if (choice === computer) {
        gameResult = 'tie';
      } else if (
        (choice === 'rock' && computer === 'scissors') ||
        (choice === 'paper' && computer === 'rock') ||
        (choice === 'scissors' && computer === 'paper')
      ) {
        gameResult = 'win';
      } else {
        gameResult = 'lose';
      }

      setResult(gameResult);
      onResult(`RPS: ${CHOICES[choice]} vs ${CHOICES[computer]} = ${gameResult.toUpperCase()}`);
      setIsPlaying(false);
    }, 1500);
  };

  const reset = () => {
    setPlayerChoice(null);
    setComputerChoice(null);
    setResult(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-gradient-to-br from-blue-900/50 to-slate-900/50 border-2 border-blue-500/50 rounded-2xl p-8 space-y-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">ROCK PAPER SCISSORS</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm"
        >
          ← Back
        </button>
      </div>

      {!result ? (
        <>
          <p className="text-center text-gray-300 text-lg">Choose your move:</p>
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(CHOICES).map(([key, emoji]) => (
              <motion.button
                key={key}
                onClick={() => play(key as Choice)}
                disabled={isPlaying}
                className="choice-btn text-6xl p-8 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded-xl transition-all"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                {emoji}
              </motion.button>
            ))}
          </div>
        </>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="grid grid-cols-2 gap-8 text-center">
            <div>
              <p className="text-sm text-gray-400 mb-2">You</p>
              <motion.div
                className="text-8xl"
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 0.5 }}
              >
                {CHOICES[playerChoice!]}
              </motion.div>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-2">Computer</p>
              <motion.div
                className="text-8xl"
                animate={{ rotate: [360, 0] }}
                transition={{ duration: 0.5 }}
              >
                {CHOICES[computerChoice!]}
              </motion.div>
            </div>
          </div>

          <motion.div
            className={`text-center p-6 rounded-xl text-3xl font-bold ${
              result === 'win'
                ? 'bg-green-900/50 text-green-400'
                : result === 'lose'
                ? 'bg-red-900/50 text-red-400'
                : 'bg-yellow-900/50 text-yellow-400'
            }`}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 0.5 }}
          >
            {result === 'win' ? '🎉 YOU WIN!' : result === 'lose' ? '💥 YOU LOSE!' : '🤝 TIE!'}
          </motion.div>

          <button
            onClick={reset}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-bold text-lg"
          >
            Play Again
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}
