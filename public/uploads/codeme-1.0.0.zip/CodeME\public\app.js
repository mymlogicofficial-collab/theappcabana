var directionEl = document.getElementById("direction");
var languageEl = document.getElementById("language");
var inputArea = document.getElementById("input-area");
var outputArea = document.getElementById("output-area");
var translateBtn = document.getElementById("translate-btn");
var unsureBtn = document.getElementById("unsure-btn");
var inputLabel = document.getElementById("input-label");
var outputLabel = document.getElementById("output-label");
var modal = document.getElementById("unsure-modal");
var closeModal = document.getElementById("close-modal");
var unsureInput = document.getElementById("unsure-input");
var getRecBtn = document.getElementById("get-recommendation");
var recResults = document.getElementById("recommendation-results");
var clearBtn = document.getElementById("clear-btn");
var exportBtn = document.getElementById("export-btn");
var importInput = document.getElementById("import-input");
var runTestBtn = document.getElementById("run-test-btn");
var clearTestBtn = document.getElementById("clear-test-btn");
var toggleTestBtn = document.getElementById("toggle-test-btn");
var testOutput = document.getElementById("test-output");

async function loadLanguages() {
  var res = await fetch("/api/languages");
  var languages = await res.json();
  languages.forEach(function (lang) {
    var opt = document.createElement("option");
    opt.value = lang;
    opt.textContent = lang;
    languageEl.appendChild(opt);
  });
}

function updateLabels() {
  if (directionEl.value === "english-to-code") {
    inputLabel.textContent = "English (what you want the code to do)";
    outputLabel.textContent = "Code Output";
    inputArea.placeholder = "Paste, type, or click SPEAK to use your voice...";
    outputArea.placeholder = "Generated code will appear here...";
  } else {
    inputLabel.textContent = "Code Input";
    outputLabel.textContent = "English Explanation";
    inputArea.placeholder = "Paste your code here...";
    outputArea.placeholder = "Plain English explanation will appear here...";
  }
}

directionEl.addEventListener("change", updateLabels);

document.querySelectorAll(".copy-btn").forEach(function (btn) {
  btn.addEventListener("click", function () {
    var target = document.getElementById(btn.dataset.target);
    if (!target.value) return;
    navigator.clipboard.writeText(target.value).then(function () {
      btn.textContent = "Copied!";
      btn.classList.add("copied");
      setTimeout(function () {
        btn.textContent = "Copy";
        btn.classList.remove("copied");
      }, 1500);
    });
  });
});

translateBtn.addEventListener("click", async function () {
  var input = inputArea.value.trim();
  if (!input) return;

  translateBtn.disabled = true;
  translateBtn.textContent = "Translating...";
  outputArea.value = "";

  try {
    var res = await fetch("/api/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        input: input,
        direction: directionEl.value,
        language: languageEl.value,
      }),
    });

    if (!res.ok) {
      var errData = await res.json();
      outputArea.value = "Error: " + (errData.error || "Translation failed.");
      translateBtn.disabled = false;
      translateBtn.textContent = "Translate";
      return;
    }

    var reader = res.body.getReader();
    var decoder = new TextDecoder();
    var buffer = "";

    while (true) {
      var result = await reader.read();
      if (result.done) break;

      buffer += decoder.decode(result.value, { stream: true });
      var lines = buffer.split("\n");
      buffer = lines.pop();

      for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (!line.startsWith("data: ")) continue;
        try {
          var event = JSON.parse(line.slice(6));
          if (event.content) {
            outputArea.value += event.content;
            outputArea.scrollTop = outputArea.scrollHeight;
          }
          if (event.error) {
            outputArea.value = "Error: " + event.error;
          }
        } catch (e) {}
      }
    }
  } catch (err) {
    outputArea.value = "Error: Could not connect to the server.";
  }

  translateBtn.disabled = false;
  translateBtn.textContent = "Translate";
});

clearBtn.addEventListener("click", function () {
  inputArea.value = "";
  outputArea.value = "";
  testOutput.textContent = "Click \"Run Code\" to test the generated code...";
});

exportBtn.addEventListener("click", function () {
  var data = {
    direction: directionEl.value,
    language: languageEl.value,
    input: inputArea.value,
    output: outputArea.value,
    timestamp: new Date().toISOString()
  };
  var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = "codeME_" + new Date().toISOString().slice(0, 10) + ".codeme";
  a.click();
  URL.revokeObjectURL(url);
});

importInput.addEventListener("change", function (e) {
  var file = e.target.files[0];
  if (!file) return;

  var reader = new FileReader();
  reader.onload = function (ev) {
    try {
      var data = JSON.parse(ev.target.result);
      if (data.direction) directionEl.value = data.direction;
      if (data.language) {
        setTimeout(function () {
          languageEl.value = data.language;
        }, 100);
      }
      if (data.input !== undefined) inputArea.value = data.input;
      if (data.output !== undefined) outputArea.value = data.output;
      updateLabels();
    } catch (err) {
      inputArea.value = ev.target.result;
    }
  };
  reader.readAsText(file);
  importInput.value = "";
});

runTestBtn.addEventListener("click", async function () {
  var code = outputArea.value.trim();
  if (!code) {
    testOutput.textContent = "[INFO] No code to run. Translate something first.";
    return;
  }

  runTestBtn.disabled = true;
  runTestBtn.textContent = "Running...";
  testOutput.textContent = "Executing code...\n";
  testOutput.classList.remove("collapsed");
  testOutput.classList.add("expanded");

  try {
    var res = await fetch("/api/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: code,
        language: languageEl.value,
      }),
    });

    var data = await res.json();
    var output = data.output || data.error || "No output.";

    testOutput.textContent = "";
    var lines = output.split("\n");
    for (var i = 0; i < lines.length; i++) {
      var span = document.createElement("span");
      span.textContent = lines[i] + "\n";
      if (lines[i].indexOf("[ERROR]") !== -1 || lines[i].indexOf("Error") !== -1 || lines[i].indexOf("Traceback") !== -1) {
        span.className = "error-line";
      } else if (lines[i].indexOf("[INFO]") !== -1 || lines[i].indexOf("[TIMEOUT]") !== -1) {
        span.className = "info-line";
      } else if (lines[i].indexOf("[OK]") !== -1) {
        span.className = "success-line";
      }
      testOutput.appendChild(span);
    }
  } catch (err) {
    testOutput.textContent = "[ERROR] Could not connect to the server.";
  }

  runTestBtn.disabled = false;
  runTestBtn.textContent = "Run Code";
});

clearTestBtn.addEventListener("click", function () {
  testOutput.textContent = "Click \"Run Code\" to test the generated code...";
});

toggleTestBtn.addEventListener("click", function () {
  if (testOutput.classList.contains("collapsed")) {
    testOutput.classList.remove("collapsed");
    testOutput.classList.add("expanded");
    toggleTestBtn.textContent = "\u25B2";
  } else {
    testOutput.classList.remove("expanded");
    testOutput.classList.add("collapsed");
    toggleTestBtn.textContent = "\u25BC";
  }
});

unsureBtn.addEventListener("click", function () {
  modal.classList.remove("hidden");
  unsureInput.focus();
});

closeModal.addEventListener("click", function () {
  modal.classList.add("hidden");
});

modal.addEventListener("click", function (e) {
  if (e.target === modal) modal.classList.add("hidden");
});

function buildRecCard(rec) {
  var card = document.createElement("div");
  card.className = "rec-card";

  var langSpan = document.createElement("span");
  langSpan.className = "lang-name";
  langSpan.textContent = rec.language;
  card.appendChild(langSpan);

  var confSpan = document.createElement("span");
  confSpan.className = "confidence " + rec.confidence;
  confSpan.textContent = rec.confidence;
  card.appendChild(confSpan);

  var reasonDiv = document.createElement("div");
  reasonDiv.className = "reason";
  reasonDiv.textContent = rec.reason;
  card.appendChild(reasonDiv);

  var useBtn = document.createElement("button");
  useBtn.className = "use-btn";
  useBtn.textContent = "Use this language";
  useBtn.addEventListener("click", function () {
    var lang = rec.language;
    for (var j = 0; j < languageEl.options.length; j++) {
      if (languageEl.options[j].value === lang) {
        languageEl.value = lang;
        break;
      }
    }
    modal.classList.add("hidden");
  });
  card.appendChild(useBtn);

  return card;
}

getRecBtn.addEventListener("click", async function () {
  var desc = unsureInput.value.trim();
  if (!desc) return;

  getRecBtn.disabled = true;
  getRecBtn.textContent = "Thinking...";
  recResults.classList.add("hidden");
  recResults.textContent = "";

  try {
    var res = await fetch("/api/recommend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ description: desc }),
    });

    var data = await res.json();

    if (data.error) {
      var errP = document.createElement("p");
      errP.style.color = "#e74c3c";
      errP.textContent = data.error;
      recResults.appendChild(errP);
    } else {
      if (data.recommendations) {
        data.recommendations.forEach(function (rec) {
          recResults.appendChild(buildRecCard(rec));
        });
      }
      if (data.summary) {
        var summaryDiv = document.createElement("div");
        summaryDiv.className = "rec-summary";
        summaryDiv.textContent = data.summary;
        recResults.appendChild(summaryDiv);
      }
    }

    recResults.classList.remove("hidden");
  } catch (err) {
    var errP = document.createElement("p");
    errP.style.color = "#e74c3c";
    errP.textContent = "Failed to get recommendations.";
    recResults.appendChild(errP);
    recResults.classList.remove("hidden");
  }

  getRecBtn.disabled = false;
  getRecBtn.textContent = "Get Recommendations";
});

inputArea.addEventListener("keydown", function (e) {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
    translateBtn.click();
  }
});

var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

function setupMic(btnId, targetId) {
  var btn = document.getElementById(btnId);
  var target = document.getElementById(targetId);
  if (!btn || !target) return;

  if (!SpeechRecognition) {
    btn.style.display = "none";
    return;
  }

  var recognition = null;
  var isRecording = false;

  btn.addEventListener("click", function () {
    if (isRecording) {
      recognition.stop();
      return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    var finalText = target.value;

    recognition.onstart = function () {
      isRecording = true;
      btn.classList.add("recording");
      btn.textContent = "Stop";
    };

    recognition.onresult = function (e) {
      var interim = "";
      for (var i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) {
          finalText += (finalText ? " " : "") + e.results[i][0].transcript;
        } else {
          interim += e.results[i][0].transcript;
        }
      }
      target.value = finalText + (interim ? " " + interim : "");
      target.scrollTop = target.scrollHeight;
    };

    recognition.onend = function () {
      isRecording = false;
      btn.classList.remove("recording");
      btn.textContent = btnId === "mic-btn" ? "\u{1F3A4} SPEAK" : "\u{1F3A4}";
      target.value = finalText;
    };

    recognition.onerror = function (e) {
      isRecording = false;
      btn.classList.remove("recording");
      btn.textContent = btnId === "mic-btn" ? "\u{1F3A4} SPEAK" : "\u{1F3A4}";
      if (e.error !== "aborted" && e.error !== "no-speech") {
        alert("Mic error: " + e.error + ". Make sure you allow microphone access.");
      }
    };

    recognition.start();
  });
}

setupMic("mic-btn", "input-area");
setupMic("mic-unsure-btn", "unsure-input");

loadLanguages();
updateLabels();
