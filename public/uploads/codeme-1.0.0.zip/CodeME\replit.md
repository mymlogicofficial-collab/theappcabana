# codeME

A minimal, cross-platform code translation web app. Translates between plain English and programming code in both directions, powered by AI.

## Features

- **English to Code**: Describe what you want in plain English, get working code in your chosen language
- **Code to English**: Paste code and get a clear plain English explanation
- **Language Advisor ("Unsure?" button)**: Describe your goal and get language recommendations
- **28 supported languages**: Python, JavaScript, TypeScript, Java, C, C++, C#, Go, Rust, Ruby, PHP, Swift, Kotlin, and more
- **Side-by-side panels**: Input on the left, output on the right — easy copy/paste workflow
- **Streaming output**: Results appear in real-time as they're generated
- **Voice input (SPEAK button)**: Dictate using browser speech recognition (Chrome/Edge)
- **Clear All**: Wipes both panels and test output in one click
- **Import/Export**: Save your work as .codeme files and reload them later
- **Test Run panel**: Execute generated Python, JavaScript, or Shell code directly and see results at the bottom
- **Copy buttons**: One-click copy on both panels
- **Keyboard shortcut**: Ctrl+Enter to translate

## Tech Stack

- **Backend**: Node.js + Express (server.js)
- **Frontend**: Vanilla HTML/CSS/JS (public/ directory)
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2)
- **Runtime**: Python 3.11 installed for code execution

## API Endpoints

- `GET /api/languages` — list supported languages
- `POST /api/translate` — SSE streaming code translation
- `POST /api/recommend` — language recommendation (JSON)
- `POST /api/run` — execute code and return output (Python, JS, Bash)

## File Structure

```
server.js          - Express server with all API endpoints
public/
  index.html       - App layout
  style.css        - Dark theme styling
  app.js           - Client-side logic (translate, mic, import/export, test runner)
```

## Running

The app runs on port 5000 via `node server.js`.
