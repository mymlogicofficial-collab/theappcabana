const express = require("express");
const path = require("path");
const OpenAI = require("openai").default;

const app = express();
const PORT = 5000;

app.use(express.json({ limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const SUPPORTED_LANGUAGES = [
  "Python", "JavaScript", "TypeScript", "Java", "C", "C++", "C#",
  "Go", "Rust", "Ruby", "PHP", "Swift", "Kotlin", "Dart",
  "R", "MATLAB", "Perl", "Scala", "Lua", "Shell/Bash",
  "SQL", "HTML/CSS", "Assembly", "Haskell", "Elixir",
  "Objective-C", "Visual Basic", "PowerShell"
];

app.get("/api/languages", (req, res) => {
  res.json(SUPPORTED_LANGUAGES);
});

app.post("/api/translate", async (req, res) => {
  const { input, direction, language } = req.body;

  if (!input || !input.trim()) {
    return res.status(400).json({ error: "Input text is required." });
  }

  if (!SUPPORTED_LANGUAGES.includes(language)) {
    return res.status(400).json({ error: "Invalid or missing language selection." });
  }

  if (direction !== "english-to-code" && direction !== "code-to-english") {
    return res.status(400).json({ error: "Invalid direction." });
  }

  let systemPrompt;

  if (direction === "english-to-code") {
    systemPrompt = `You are a code translator. The user will describe what they want in plain English. Generate clean, working code in ${language}. Output ONLY the code — no explanations, no markdown fences, no comments unless they are essential for understanding. The code should be production-ready and handle edge cases.`;
  } else if (direction === "code-to-english") {
    systemPrompt = `You are a code explainer. The user will paste code (likely ${language}, but auto-detect if needed). Explain what the code does in clear, plain English. Be thorough but concise. Break down the logic step by step. If there are any bugs or issues, mention them. Do NOT output any code — only English explanation.`;
  }

  try {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: input },
      ],
      stream: true,
      max_completion_tokens: 8192,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (error) {
    console.error("Translation error:", error);
    if (res.headersSent) {
      res.write(`data: ${JSON.stringify({ error: "Translation failed. Please try again." })}\n\n`);
      res.end();
    } else {
      res.status(500).json({ error: "Translation failed. Please try again." });
    }
  }
});

app.post("/api/recommend", async (req, res) => {
  const { description } = req.body;

  if (!description || !description.trim()) {
    return res.status(400).json({ error: "Description is required." });
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5.2",
      messages: [
        {
          role: "system",
          content: `You are a programming language advisor. The user will describe what they want to build or accomplish. Recommend the best programming language(s) for the task. Return a JSON object with this exact structure:
{
  "recommendations": [
    {
      "language": "Language Name",
      "reason": "Brief reason why this is a good fit",
      "confidence": "high/medium/low"
    }
  ],
  "summary": "A brief overall recommendation in 1-2 sentences"
}
Return 1-3 recommendations, ranked by best fit. Only recommend from commonly used languages.`,
        },
        { role: "user", content: description },
      ],
      max_completion_tokens: 8192,
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0]?.message?.content || "{}");
    res.json(result);
  } catch (error) {
    console.error("Recommendation error:", error);
    res.status(500).json({ error: "Failed to get recommendations. Please try again." });
  }
});

app.post("/api/run", async (req, res) => {
  const { code, language } = req.body;

  if (!code || !code.trim()) {
    return res.status(400).json({ error: "No code to run." });
  }

  const langLower = (language || "").toLowerCase();
  let cmd, args, ext;

  if (langLower === "python") {
    cmd = "python3"; args = ["-u"]; ext = ".py";
  } else if (langLower === "javascript") {
    cmd = "node"; args = []; ext = ".js";
  } else if (langLower === "shell/bash") {
    cmd = "bash"; args = []; ext = ".sh";
  } else {
    return res.json({
      output: "[INFO] Direct execution is supported for Python, JavaScript, and Shell/Bash.\nFor other languages, copy the code and run it in your local environment."
    });
  }

  const { execFile, execSync } = require("child_process");
  const fs = require("fs");
  const os = require("os");
  const tmpFile = path.join(os.tmpdir(), "codeme_test_" + Date.now() + ext);

  try {
    fs.writeFileSync(tmpFile, code);
    const allArgs = args.concat([tmpFile]);

    const result = await new Promise((resolve) => {
      execFile(cmd, allArgs, { timeout: 10000, maxBuffer: 1024 * 512 }, (error, stdout, stderr) => {
        let output = "";
        if (stdout) output += stdout;
        if (stderr) output += (output ? "\n" : "") + stderr;
        if (error && error.code === "ENOENT") {
          output = "[ERROR] Runtime '" + cmd + "' is not available in this environment.\nThe code looks correct but cannot be executed here.";
        } else if (error && error.killed) {
          output += "\n[TIMEOUT] Code execution exceeded 10 second limit.";
        } else if (error && !stderr) {
          output += "\n[ERROR] " + error.message;
        }
        resolve({ output: output || "[OK] Code ran with no output." });
      });
    });

    res.json(result);
  } catch (err) {
    res.json({ output: "[ERROR] " + err.message });
  } finally {
    try { fs.unlinkSync(tmpFile); } catch (e) {}
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`codeME running on port ${PORT}`);
});
