# Fortune Spheres Vol. 1

Five mystical spheres, each with her own unique personality and perspective on life's biggest questions.

## The Spheres

🎀 **Becky** - The Anxious Babysitter  
Everything is an issue waiting to happen. She sees every worst-case scenario.

✨ **Tiff** - The Astro-Fashion Columnist  
Everything is written in the stars and your wardrobe. Mercury's always up to something.

🌙 **Luna** - The Midnight Mystic  
Wisdom from the shadows. Speaks in riddles and cosmic truths you didn't know you needed.

⚡ **Ziggy** - The Chaos Agent  
Unhinged energy. Makes you want to yeet it all into the void. Surprisingly solid takes though.

👑 **Oracle** - The No-BS Truthteller  
Cuts through the excuses. Your gut already knows the answer; she just confirms it.

## Features

- **5 Unique Personalities** — Each with 20+ randomized responses
- **Smart Questioning** — Ask your question to any sphere
- **Shake Animation** — Animated ball-shaking mechanic
- **Auto-Select Mode** — Let the timer randomly pick a sphere every 5-15 seconds
- **Gorgeous UI** — Gradient backgrounds, smooth animations, responsive design
- **No AI Needed** — Pre-written personality responses (saves costs, guarantees uniqueness)

## Installation

### Local Development

```bash
npm install
npm run dev:client
```

Visit `http://localhost:5000`

### Production Build

```bash
npm install
npm run build
```

Dist files in `dist/public/`

## How to Use

1. **Select a Sphere** — Click any of the five personality balls
2. **Ask Your Question** — Type what's on your mind
3. **Shake the Sphere** — Click the shake button to get her take
4. **Get Her Answer** — Each sphere responds from her unique perspective
5. **Ask Again** — Get different answers by shaking again (each has 20+ responses)

### Auto-Select Mode

Click "Auto-Select ON" to let the random timer pick a sphere every 5-15 seconds. Perfect for when you can't decide or want pure chaos.

## Tech Stack

- React 19
- TypeScript
- Tailwind CSS
- Framer Motion (animations)
- Vite (build tool)

## Project Structure

```
fortune-spheres/
├── client/src/
│   ├── components/
│   │   ├── BallSelector.tsx    # Sphere selection UI
│   │   └── FortuneSphere.tsx   # Main fortune display
│   ├── lib/
│   │   └── personalities.ts    # All 5 ball personalities + responses
│   ├── App.tsx                 # Main app logic
│   └── index.css
├── package.json
├── vite.config.ts
└── tsconfig.json
```

## Customization

### Add More Personalities

Edit `client/src/lib/personalities.ts`:

```typescript
export const YOUR_BALL: BallPersonality = {
  id: 'yourball',
  name: 'Your Name',
  color: '#hexcolor',
  description: 'Your vibe description',
  emoji: '🎭',
  responses: [
    "Response 1",
    "Response 2",
    // ... add 20+ unique responses
  ]
};
```

Then add to `PERSONALITIES` array at the bottom.

### Change Colors

All colors defined in `personalities.ts` using hex values. Update any ball's `color` field.

## Deployment

### Docker

```bash
docker build -t fortune-spheres .
docker run -p 5000:5000 fortune-spheres
```

### Railway / Heroku

Push repo and set build command to `npm run build`. Static files will be served from `dist/public/`.

## License

MIT

---

**Version 1.0.0** | Made with 🔮 and chaos
