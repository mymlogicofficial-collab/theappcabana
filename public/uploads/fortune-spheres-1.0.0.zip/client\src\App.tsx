import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PERSONALITIES, FART_RESPONSES, type BallPersonality } from '@/lib/personalities';
import BallSelector from '@/components/BallSelector';
import FortuneSphere from '@/components/FortuneSphere';
import './App.css';

export default function App() {
  const [selectedBall, setSelectedBall] = useState<BallPersonality | null>(null);
  const [autoSelectBall, setAutoSelectBall] = useState<BallPersonality | null>(null);
  const [timerActive, setTimerActive] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [questionCount, setQuestionCount] = useState(0);
  const [isFartResponse, setIsFartResponse] = useState(false);

  // Random timer - selects a ball every 5-15 seconds
  useEffect(() => {
    if (!timerActive) return;

    const randomInterval = Math.random() * 10000 + 5000; // 5-15 seconds
    const timer = setTimeout(() => {
      const randomBall = PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)];
      setAutoSelectBall(randomBall);
      setSelectedBall(randomBall);
    }, randomInterval);

    return () => clearTimeout(timer);
  }, [timerActive, autoSelectBall]);

  const handleBallSelect = (ball: BallPersonality) => {
    setSelectedBall(ball);
    setAutoSelectBall(null);
    setTimerActive(false);
    setAnswer(null);
    setIsFartResponse(false);
  };

  const handleShake = async () => {
    if (!selectedBall || !question.trim()) return;

    setIsShaking(true);
    setAnswer(null);
    setIsFartResponse(false);

    // Simulate shake duration
    await new Promise(resolve => setTimeout(resolve, 2000));

    // 10% chance of fart response
    const isFart = Math.random() < 0.1;

    let randomResponse: string;
    if (isFart) {
      randomResponse = FART_RESPONSES[Math.floor(Math.random() * FART_RESPONSES.length)];
      setIsFartResponse(true);
    } else {
      randomResponse = selectedBall.responses[
        Math.floor(Math.random() * selectedBall.responses.length)
      ];
    }

    setAnswer(randomResponse);
    setIsShaking(false);

    // Increment question count
    const newCount = questionCount + 1;
    setQuestionCount(newCount);

    // Every ~9 questions, auto-grab a random different ball
    if (newCount % 9 === 0 && newCount > 0) {
      await new Promise(resolve => setTimeout(resolve, 1500));
      const randomBall = PERSONALITIES.filter(b => b.id !== selectedBall.id)[
        Math.floor(Math.random() * (PERSONALITIES.length - 1))
      ];
      setAutoSelectBall(randomBall);
      setSelectedBall(randomBall);
      setAnswer(null);
      setQuestionCount(0);
    }
  };

  const toggleAutoSelect = () => {
    setTimerActive(!timerActive);
    if (!timerActive) {
      setAnswer(null);
      setQuestion('');
      setQuestionCount(0);
    }
  };

  return (
    <div className="fortune-spheres-app">
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-6">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-2 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent">
            ✨ Fortune Spheres ✨
          </h1>
          <p className="text-gray-300 text-lg">Ask your question. Choose your sphere. Get your truth.</p>
          {questionCount > 0 && questionCount % 9 !== 0 && (
            <p className="text-xs text-gray-400 mt-2">Questions asked: {questionCount} (auto-grab at 9)</p>
          )}
        </header>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Left: Ball Selector */}
          <div className="lg:col-span-1">
            <BallSelector 
              personalities={PERSONALITIES}
              selectedBall={selectedBall}
              onSelect={handleBallSelect}
              autoSelected={autoSelectBall}
            />

            {/* Auto-Select Toggle */}
            <motion.button
              onClick={toggleAutoSelect}
              className={`w-full mt-6 py-3 rounded-lg font-bold text-lg transition-all ${
                timerActive
                  ? 'bg-purple-600 hover:bg-purple-700 text-white'
                  : 'bg-gray-700 hover:bg-gray-600 text-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {timerActive ? '⏱️ Auto-Select ON' : '⏱️ Auto-Select OFF'}
            </motion.button>
          </div>

          {/* Right: Fortune Interface */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {selectedBall ? (
                <FortuneSphere
                  key={selectedBall.id}
                  ball={selectedBall}
                  question={question}
                  onQuestionChange={setQuestion}
                  answer={answer}
                  onShake={handleShake}
                  isShaking={isShaking}
                  isFartResponse={isFartResponse}
                />
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-gradient-to-br from-purple-900/50 to-slate-900/50 border border-purple-500/30 rounded-2xl p-8 text-center"
                >
                  <p className="text-2xl text-gray-300 mb-4">Select a sphere to begin...</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-gray-400">
                    <div>🎀 Becky - The Worrier</div>
                    <div>✨ Tiff - The Astrologer</div>
                    <div>🌙 Luna - The Mystic</div>
                    <div>⚡ Ziggy - The Chaos</div>
                    <div>👑 Oracle - The Truth</div>
                    <div>🚐 Seth - The Stoner</div>
                    <div>🔴 Joe - The Investigator</div>
                    <div>🔵 Jerri - The Meh Mystic</div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
