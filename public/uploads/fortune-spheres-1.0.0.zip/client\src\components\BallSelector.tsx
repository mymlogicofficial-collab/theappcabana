import { motion } from 'framer-motion';
import { BallPersonality } from '@/lib/personalities';

interface BallSelectorProps {
  personalities: BallPersonality[];
  selectedBall: BallPersonality | null;
  onSelect: (ball: BallPersonality) => void;
  autoSelected: BallPersonality | null;
}

export default function BallSelector({
  personalities,
  selectedBall,
  onSelect,
  autoSelected,
}: BallSelectorProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-6">Choose Your Sphere</h2>
      
      <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-2">
        {personalities.map((ball) => (
          <motion.button
            key={ball.id}
            onClick={() => onSelect(ball)}
            className={`relative p-4 rounded-xl transition-all border-2 ${
              selectedBall?.id === ball.id
                ? 'border-white bg-opacity-20'
                : autoSelected?.id === ball.id
                ? 'border-yellow-400 bg-opacity-10 animate-pulse'
                : 'border-gray-600 hover:border-gray-400'
            }`}
            style={{
              backgroundColor:
                selectedBall?.id === ball.id
                  ? ball.color + '30'
                  : autoSelected?.id === ball.id
                  ? ball.color + '20'
                  : 'transparent',
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {/* Sphere Visual */}
            <motion.div
              className="w-12 h-12 mx-auto mb-2 rounded-full shadow-lg"
              style={{ backgroundColor: ball.color }}
              animate={autoSelected?.id === ball.id ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 0.6, repeat: Infinity }}
            >
              <div className="w-full h-full flex items-center justify-center text-xl">
                {ball.emoji}
              </div>
            </motion.div>

            {/* Ball Info */}
            <div className="text-left">
              <p className="font-bold text-white text-sm">{ball.name}</p>
              <p className="text-xs text-gray-300 line-clamp-2">{ball.description}</p>
            </div>

            {/* Selected Indicator */}
            {selectedBall?.id === ball.id && (
              <motion.div
                layoutId="selectedIndicator"
                className="absolute top-2 right-2 w-3 h-3 bg-white rounded-full"
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 0.5 }}
              />
            )}

            {/* Auto-Select Indicator */}
            {autoSelected?.id === ball.id && (
              <motion.div
                className="absolute top-2 right-2 text-yellow-400"
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                ⏱️
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}
