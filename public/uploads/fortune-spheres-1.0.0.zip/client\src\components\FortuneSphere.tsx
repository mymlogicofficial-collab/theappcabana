import { motion } from 'framer-motion';
import { BallPersonality } from '@/lib/personalities';

interface FortuneSphereProps {
  ball: BallPersonality;
  question: string;
  onQuestionChange: (question: string) => void;
  answer: string | null;
  onShake: () => void;
  isShaking: boolean;
  isFartResponse?: boolean;
}

export default function FortuneSphere({
  ball,
  question,
  onQuestionChange,
  answer,
  onShake,
  isShaking,
  isFartResponse = false,
}: FortuneSphereProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="space-y-6"
    >
      {/* Sphere Visual - Main Display */}
      <div className="flex justify-center">
        <motion.div
          className="relative w-48 h-48 rounded-full shadow-2xl flex items-center justify-center text-7xl"
          style={{ backgroundColor: ball.color }}
          animate={isShaking ? {
            x: [0, -20, 20, -15, 15, 0],
            y: [0, 20, -20, 15, -15, 0],
            rotate: [0, -10, 10, -10, 10, 0],
          } : {
            rotate: 0,
            x: 0,
            y: 0,
          }}
          transition={isShaking ? {
            duration: 0.6,
            repeat: Infinity,
          } : {
            duration: 0.3,
          }}
        >
          {ball.emoji}
          
          {/* Shine Effect */}
          <motion.div
            className="absolute inset-0 rounded-full opacity-0"
            style={{
              background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.6), transparent)',
            }}
            animate={{ opacity: [0, 0.3, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
          />
        </motion.div>
      </div>

      {/* Ball Info */}
      <div className="text-center">
        <h3 className="text-3xl font-bold mb-1">{ball.name}</h3>
        <p className="text-gray-300">{ball.description}</p>
      </div>

      {/* Question Input */}
      <div className="space-y-3">
        <label className="block text-sm font-semibold text-gray-200">
          Ask your question:
        </label>
        <textarea
          value={question}
          onChange={(e) => onQuestionChange(e.target.value)}
          placeholder="What does your heart desire...?"
          className="w-full p-4 rounded-lg bg-slate-800 border border-gray-600 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:ring-2 focus:ring-purple-500/50 resize-none"
          rows={4}
        />
      </div>

      {/* Shake Button */}
      <motion.button
        onClick={onShake}
        disabled={!question.trim() || isShaking}
        className={`w-full py-4 rounded-lg font-bold text-lg transition-all ${
          isShaking
            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white animate-pulse'
            : question.trim()
            ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white'
            : 'bg-gray-700 text-gray-400 cursor-not-allowed'
        }`}
        whileHover={question.trim() && !isShaking ? { scale: 1.05 } : {}}
        whileTap={question.trim() && !isShaking ? { scale: 0.95 } : {}}
      >
        {isShaking ? '🔮 Shaking...' : '🔮 Shake the Sphere'}
      </motion.button>

      {/* Answer Display */}
      {answer && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className={`border-2 rounded-xl p-6 ${
            isFartResponse
              ? 'bg-gradient-to-br from-amber-900/50 to-orange-900/50 border-amber-500/50'
              : 'bg-gradient-to-br from-purple-900/50 to-slate-900/50 border-purple-500/50'
          }`}
        >
          <p className={`text-sm font-semibold mb-2 ${
            isFartResponse ? 'text-amber-300' : 'text-purple-300'
          }`}>
            {isFartResponse ? '💨 The Sphere Senses...' : 'The Sphere Speaks:'}
          </p>
          <motion.p
            className="text-xl font-bold text-white leading-relaxed"
            animate={{ opacity: [0.5, 1] }}
            transition={{ duration: 0.5 }}
          >
            "{answer}"
          </motion.p>
        </motion.div>
      )}

      {/* Fun Tips */}
      <div className="text-center text-xs text-gray-400 space-y-1">
        <p>💡 Each sphere has her own unique personality</p>
        <p>🔄 Ask again to receive a different answer</p>
        <p>💨 Occasionally... something else might be detected</p>
      </div>
    </motion.div>
  );
}
