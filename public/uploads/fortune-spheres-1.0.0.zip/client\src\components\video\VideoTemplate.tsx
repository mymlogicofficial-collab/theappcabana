import { AnimatePresence, motion, type Transition } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video';
import ballImage from '@assets/just-sayn_1772606091096.jpg';
import { IntroScene, QuestionScene, ShakeScene, AnswerScene, RapidFireScene } from './scenes';

const SCENE_DURATIONS = {
  intro: 4000,
  q1: 3000,
  shake1: 2000,
  a1: 3500,
  q2: 3000,
  shake2: 2000,
  a2: 3500,
  q3: 3000,
  shake3: 2000,
  a3: 4000,
  rapid: 6000,
};

export default function VideoTemplate() {
  const { currentSceneKey, currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  const isShaking = currentSceneKey?.startsWith('shake') || currentSceneKey === 'rapid';
  
  const ballAnimation = isShaking ? {
    x: [0, -15, 20, -20, 15, 0],
    y: [0, 20, -15, 15, -20, 0],
    rotate: [0, -8, 8, -5, 5, 0],
    scale: 1.15,
    filter: 'blur(3px)',
  } : {
    x: 0,
    y: 0,
    rotate: currentSceneKey?.startsWith('a') ? 0 : (currentScene === 0 ? 180 : 30),
    scale: currentSceneKey?.startsWith('a') ? 1.2 : 1,
    filter: 'blur(0px)',
  };

  const ballTransition: Transition = isShaking ? {
    repeat: Infinity,
    duration: 0.1,
  } : {
    type: 'spring',
    stiffness: 120,
    damping: 20,
  } as Transition;

  return (
    <div 
      className="w-full h-screen overflow-hidden relative flex items-center justify-center"
      style={{ 
        backgroundColor: 'var(--color-bg-dark)',
        aspectRatio: '16 / 9',
      }}
    >
      {/* Background ambient motion */}
      <motion.div 
        className="absolute inset-0 opacity-30"
        style={{
          background: 'radial-gradient(circle at 50% 50%, var(--color-secondary) 0%, transparent 70%)',
        }}
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Noise Texture */}
      <div className="absolute inset-0 opacity-10 mix-blend-overlay pointer-events-none" 
           style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}>
      </div>

      {/* Persistent Ball */}
      <motion.div
        className="absolute z-20 rounded-full shadow-[0_0_80px_rgba(255,0,85,0.3)] overflow-hidden"
        style={{ width: 'min(60vh, 50vw)', height: 'min(60vh, 50vw)' }}
        animate={ballAnimation}
        transition={ballTransition}
      >
        <motion.img 
          src={ballImage} 
          alt="FortuneRiffer" 
          className="w-full h-full object-cover scale-[1.3]"
          animate={{ rotate: currentScene * 15, scale: currentSceneKey?.startsWith('a') ? 1.5 : 1.3 }}
          transition={{ duration: 1.5, ease: "circOut" }}
        />
        <div className="absolute inset-0 rounded-full shadow-[inset_-30px_-30px_80px_rgba(0,0,0,0.9),inset_10px_10px_40px_rgba(255,255,255,0.4)] pointer-events-none" />
      </motion.div>

      {/* Foreground Content */}
      <AnimatePresence>
        {currentSceneKey === 'intro' && <IntroScene key="intro" />}
        
        {currentSceneKey === 'q1' && <QuestionScene key="q1" text="oh FortuneRiffer!! will i meet someone today???" />}
        {currentSceneKey === 'shake1' && <ShakeScene key="shake1" />}
        {currentSceneKey === 'a1' && <AnswerScene key="a1" text="we all do" />}
        
        {currentSceneKey === 'q2' && <QuestionScene key="q2" text="will you ever stop being bitter?" />}
        {currentSceneKey === 'shake2' && <ShakeScene key="shake2" />}
        {currentSceneKey === 'a2' && <AnswerScene key="a2" text="did you just fart?" />}
        
        {currentSceneKey === 'q3' && <QuestionScene key="q3" text="if i say yes will you stop ask'n?" />}
        {currentSceneKey === 'shake3' && <ShakeScene key="shake3" />}
        {currentSceneKey === 'a3' && <AnswerScene key="a3" text="ask again later" />}
        
        {currentSceneKey === 'rapid' && <RapidFireScene key="rapid" />}
      </AnimatePresence>
    </div>
  );
}