import { motion } from 'framer-motion';
import { containerVariants, itemVariants } from '@/lib/video';
import { useEffect, useState } from 'react';

const answers = [
  "no", "yes", "sure", "maybe", "ok", "ask again later", "again?.....",
  "we all do", "did you just fart?", "if i say yes will stop ask'n?",
  "whatever", "who cares", "shut up", "nope.", "try harder", "lol no",
  "yikes", "blame the dev", "404 answer not found", "is that a joke?",
  "outlook bleak", "my sources say no", "very doubtful", "as if",
  "don't bet on it", "obviously not", "in your dreams", "get a grip",
  "I'm sleeping", "error 500", "please stop", "I guess", "probably",
  "100% yes", "100% no", "why do you care?", "ask someone else",
  "not a chance", "it is certain", "without a doubt", "yes, totally",
  "you wish", "maybe next time", "try tomorrow", "it's a mystery"
];

export const IntroScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none"
      initial="hidden"
      animate="visible"
      exit="hidden"
      variants={containerVariants}
    >
      <motion.div className="absolute inset-0 bg-black/60 backdrop-blur-sm" variants={itemVariants} />
      <motion.h1 
        className="font-display font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-neutral-500 tracking-tighter z-10 drop-shadow-2xl"
        style={{ fontSize: 'clamp(2rem, 10vw, 12rem)' }}
        initial={{ scale: 0.8, opacity: 0, y: 50 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 1.5, opacity: 0, filter: 'blur(20px)' }}
        transition={{ type: 'spring', stiffness: 100, damping: 20 }}
      >
        FortuneRiffer
      </motion.h1>
      <motion.p
        className="absolute text-red-500 font-mono tracking-[0.3em] uppercase z-10 font-bold"
        style={{ fontSize: 'clamp(1rem, 2.5vw, 1.5rem)', bottom: '12vh' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        The All-Seer of Sarcasm
      </motion.p>
    </motion.div>
  );
};

export const QuestionScene = ({ text }: { text: string }) => {
  return (
    <motion.div
      className="absolute inset-0 flex items-start justify-center pt-[12vh] px-8 z-30 pointer-events-none"
      initial="hidden"
      animate="visible"
      exit="hidden"
      variants={containerVariants}
    >
      <motion.div className="absolute top-0 inset-x-0 bg-gradient-to-b from-black/90 to-transparent h-[50vh]" variants={itemVariants} />
      <motion.h2 
        className="text-white font-display font-bold text-center leading-tight tracking-tight drop-shadow-[0_10px_30px_rgba(0,0,0,1)] z-10"
        style={{ fontSize: 'clamp(1.5rem, 6vw, 4rem)', maxWidth: '90vw' }}
        variants={itemVariants}
      >
        "{text}"
      </motion.h2>
    </motion.div>
  );
};

export const ShakeScene = () => {
  const [scrambleText, setScrambleText] = useState("...");
  
  useEffect(() => {
    const interval = setInterval(() => {
      setScrambleText(answers[Math.floor(Math.random() * answers.length)]);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
       <div className="relative flex items-center justify-center">
        <motion.div 
          className="absolute w-[22vh] h-[22vh] bg-blue-900/60 backdrop-blur-md shadow-[inset_0_0_50px_rgba(0,0,0,0.9)]"
          style={{ clipPath: 'polygon(50% 15%, 5% 85%, 95% 85%)' }}
          animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 0.1 }}
        >
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-[15%] px-4">
            <p className="text-blue-100/50 font-mono font-bold text-center blur-[1px] leading-tight" style={{ fontSize: 'clamp(0.6rem, 1.5vw, 1rem)' }}>
              {scrambleText}
            </p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export const AnswerScene = ({ text }: { text: string }) => {
  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none"
      initial={{ opacity: 0, scale: 0.8, filter: 'blur(10px)' }}
      animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, scale: 1.2, filter: 'blur(10px)' }}
      transition={{ type: 'spring', stiffness: 200, damping: 20 }}
    >
      <div className="relative flex items-center justify-center">
        <motion.div 
          className="absolute w-[28vh] h-[28vh] bg-blue-900/90 backdrop-blur-md border border-blue-400/30 shadow-[inset_0_0_60px_rgba(0,0,0,0.9),0_0_50px_rgba(0,100,255,0.3)]"
          style={{ clipPath: 'polygon(50% 10%, 0% 90%, 100% 90%)' }}
          initial={{ rotate: -180, scale: 0 }}
          animate={{ rotate: 0, scale: 1 }}
          transition={{ type: 'spring', stiffness: 100, damping: 15, delay: 0.1 }}
        >
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-[15%] px-6">
            <motion.p 
              className="text-blue-50 font-mono font-bold text-center tracking-tighter uppercase leading-tight drop-shadow-md"
              style={{ fontSize: 'clamp(0.75rem, 1.8vw, 1.25rem)' }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              {text}
            </motion.p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export const RapidFireScene = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % answers.length);
    }, 150);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.5 }}
    >
      <div className="relative flex items-center justify-center">
        <motion.div 
          className="absolute w-[35vh] h-[35vh] bg-blue-950/90 backdrop-blur-xl shadow-[inset_0_0_80px_rgba(0,0,0,0.9),0_0_100px_rgba(255,0,0,0.5)]"
          style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }}
          animate={{ rotate: [0, -2, 2, 0], scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 0.2 }}
        >
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-[15%] px-8">
            <p className="text-red-400 font-display font-black text-center tracking-tighter uppercase leading-none drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]" style={{ fontSize: 'clamp(1rem, 4vw, 2.5rem)' }}>
              {answers[currentIndex]}
            </p>
          </div>
        </motion.div>
      </div>
      <motion.div 
        className="absolute inset-0 bg-red-900/20 mix-blend-overlay"
        animate={{ opacity: [0, 0.5, 0] }}
        transition={{ repeat: Infinity, duration: 0.3 }}
      />
    </motion.div>
  );
};