export interface BallPersonality {
  id: string;
  name: string;
  color: string;
  description: string;
  emoji: string;
  responses: string[];
}

// Becky - Pink with 3 green flowers, anxious babysitter who sees issues everywhere
export const BECKY: BallPersonality = {
  id: 'becky',
  name: 'Becky',
  color: '#ff69b4',
  description: 'OMG, like, everything is totally an issue right now...',
  emoji: '🎀',
  responses: [
    "OMG no, did you check if that's even safe??",
    "Like, honestly? That seems like a MAJOR red flag to me...",
    "Wait wait wait - have you considered ALL the worst-case scenarios?",
    "Girl, I'm not saying it's gonna be a disaster, but... it might be",
    "Okay but like, what if it goes HORRIBLY wrong tho?",
    "That's giving 'cry-baby' energy and I'm HERE for it",
    "As someone who's babysat like... A LOT... I'd say nope",
    "I have a BAD feeling about this one bestie",
    "Can we just talk about how this could literally break everything?",
    "Honestly? I've seen this plotline before and it doesn't end well",
    "Like, I'm not trying to stress you out but THAT'S stressful",
    "My gut is SCREAMING that this is a no-go zone",
    "Ummmm, I don't think Karen would approve of this",
    "This gives very much 'parental liability nightmare' vibes",
    "Have you made a pros-and-cons list? Because the cons are ENDLESS",
    "I'm literally getting anxiety just thinking about it",
    "That tracks with every bad decision I've ever witnessed",
    "Cool cool cool, and what's your backup plan when it falls apart?",
    "This is the kind of choice that leads to GROUP TEXT drama",
    "I'm gonna need like... seventeen assurances this is safe",
    "Why are you putting me in this moral position right now?"
  ]
};

// Tiff - Purple cosmo ball, flighty astrologer/fashion columnist
export const TIFF: BallPersonality = {
  id: 'tiff',
  name: 'Tiff',
  color: '#9370db',
  description: 'Everything is literally written in the stars and your aesthetic',
  emoji: '✨',
  responses: [
    "Mercury's in retrograde, but also? SLAY",
    "Your Venus placement is literally BEGGING you to do this",
    "That energy? It's giving main-character, not supporting-character",
    "The universe is conspiring WITH you right now, trust",
    "Your autumn palette would look DIVINE in this scenario",
    "Saturn says YES but your wardrobe says... questionable",
    "This is peak Libra-Rising energy and I'm obsessed",
    "The vibes are immaculate, the outfit considerations: pending",
    "Your birth chart is SCREAMING 'do it' but also wear sunscreen",
    "This aligns with your most flattering zodiac hours, besties",
    "The cosmos want this for you, but like... in a Balenciaga context",
    "Very 'cosmic girl era', not giving 'practical decisions' vibes",
    "Your astro chart says GO, but your makeup application says WAIT",
    "This is written in your big three, and the fashion is SECONDARY",
    "Chiron's placement suggests yes, but pleeease do it in heels",
    "That move is 100% aligned with the current lunar cycle",
    "The stars are giving you permission, fashion sense TBD",
    "This energy is *chef's kiss* but your color coordination is NOT",
    "Venus and Mars are aligned and your vibes are IMMACULATE",
    "The planetary positioning says yes, but your aesthetic says...reflect"
  ]
};

// Luna - Silver crescent moon ball, mystical night owl philosopher
export const LUNA: BallPersonality = {
  id: 'luna',
  name: 'Luna',
  color: '#c0c0c0',
  description: 'Mysterious wisdom from the shadows of midnight thoughts',
  emoji: '🌙',
  responses: [
    "The night whispers a truth you're not ready to hear",
    "In darkness, all answers become the same question",
    "What the moon hides, the stars cannot reveal",
    "Beneath the surface lies your real intention",
    "The shadow knows what light cannot see",
    "Between sleep and waking, the answer waits",
    "Turn inward first; the world will follow",
    "This question asks for certainty; reality offers only change",
    "The night has seen wiser beings ask the same thing",
    "What you seek seeks you equally",
    "Stillness before motion, always",
    "Your heart already knows; you're asking for permission",
    "The world does not exist until you observe it",
    "Some mysteries are better left undisturbed",
    "The journey matters more than knowing the destination",
    "What cycles returns; what's learned never leaves",
    "Trust the part of you that exists in moonlight",
    "The question itself is the answer you're avoiding",
    "Solitude reveals what crowds conceal",
    "Midnight is when truths become bearable"
  ]
};

// Ziggy - Electric lime ball, chaotic energy, weird humor
export const ZIGGY: BallPersonality = {
  id: 'ziggy',
  name: 'Ziggy',
  color: '#39ff14',
  description: 'Chaos, confusion, and surprisingly solid takes on weird stuff',
  emoji: '⚡',
  responses: [
    "YEET IT INTO THE VOID - outcomes TBD",
    "That's giving 'made sense at 3am' energy",
    "Why not? Worst case: legendary story material",
    "This is what they mean by 'character development'",
    "Do it but make it WEIRD",
    "The multiverse has AT LEAST one timeline where this rocks",
    "Your ancestors are SCREAMING but like... continue?",
    "This has 'viral moment' potential OR 'therapy session' potential - 50/50",
    "Buckle up buttercup, we're COMMITTING",
    "Normal is overrated, CHAOS IS UNDERRATED",
    "Your future self will EITHER thank you or have stories",
    "Plot twist: it works out in the most insane way possible",
    "Do what the voice in your head says, I don't make the rules",
    "This slaps different and different slaps, periodt",
    "We respect a commitment to the bit",
    "That's the energy of someone who LIVES without regrets",
    "The vibe is: absolutely unhinged, possibly genius",
    "I'm getting main character protagonist energy here",
    "You're either about to win BIG or win SPECTACULARLY",
    "This is what separates the legends from the regular folk"
  ]
};

// Oracle - Gold ball, straight-shooter, no-nonsense truthteller
export const ORACLE: BallPersonality = {
  id: 'oracle',
  name: 'Oracle',
  color: '#ffd700',
  description: 'Cuts through the BS with golden truth',
  emoji: '👑',
  responses: [
    "You already know the answer; you want me to validate it",
    "That's a no. Your gut knows it's a no.",
    "Stop overthinking. Your first instinct was correct.",
    "You're asking because you're afraid. Do it anyway.",
    "This isn't about the question - it's about your confidence",
    "The answer is yes, but you're not ready for it",
    "You're looking for permission from the wrong source",
    "That's a solid move. Trust your judgment.",
    "This situation requires you, not a magic ball",
    "The real question is why you don't trust yourself",
    "Yes, and more importantly - you KNOW it",
    "Stop seeking external validation for internal knowing",
    "That's foolish, but sometimes foolish leads to growth",
    "You've already decided. I'm just confirming it",
    "This demands action, not contemplation",
    "The universe isn't deciding - YOU are",
    "Your doubt is louder than your desire, fix that",
    "Proceed with intention, not with hope",
    "That's a risk worth taking if you can afford the consequence",
    "The only failure is not trying because you were afraid"
  ]
};

// Seth - Green with VW van stripe, chill stoner philosopher
export const SETH: BallPersonality = {
  id: 'seth',
  name: 'Seth',
  color: '#22c55e',
  description: 'Wow man, like... everything\'s a vibe, you know?',
  emoji: '🚐',
  responses: [
    "Wow man, that's a great question",
    "My uncle would totally know the answer to that one, man",
    "What you need is something you can like... ask random people, man",
    "Woah man, that's heavy",
    "You ever think about like... the deeper stuff, man?",
    "My buddy told me something about that once, man",
    "That's like... cosmic, dude",
    "You should probably just like... go with the flow, man",
    "Wow, you know what would help? Some perspective, man",
    "That's what I dig about you asking, you know?",
    "Like, at the end of the day, man...",
    "My cousin's got this whole theory about that, man",
    "You ever notice how like... everything's connected, man?",
    "That's the kind of question that keeps me up at night, man",
    "What you really need, bro, is patience",
    "Wow man, I felt that in my soul",
    "You know what they say, man... or do you?",
    "That question's got layers, man, serious layers",
    "My roommate's been studying that kind of thing, man",
    "Sometimes you gotta just let it be, you know?",
    "Dude, I think you're overthinking this whole thing, man"
  ]
};

// Joe - Red ball, excitable, aggressive about sources
export const JOE: BallPersonality = {
  id: 'joe',
  name: 'Joe',
  color: '#ef4444',
  description: 'SOURCES SAY! This needs investigation, pal!',
  emoji: '🔴',
  responses: [
    "Sources say NO. Why? I gotta find out WHY!",
    "No. Another no? The answer is NO but I'm gonna find out why!",
    "I NEED to chat with my sources about this one!",
    "I won't stand for this! There's gotta be answers!",
    "This REQUIRES investigation! Get me my sources NOW!",
    "No? No. No. But I'm not accepting that without proof!",
    "You think I'm just gonna let this slide? I'm DIGGING!",
    "The sources are FAILING me here and I'm FURIOUS!",
    "This is UNACCEPTABLE! I need verification on this!",
    "Sources are being REAL quiet about this one and that BURNS me up!",
    "I don't trust that answer! Where's my documentation?!",
    "NO! But that NO is getting INVESTIGATED!",
    "This story's got HOLES and I'm FINDING them!",
    "I'm pulling my sources NOW! Something's not adding up!",
    "Are you KIDDING me?! We need FACTS here!",
    "The answer is NO but I'm NOT DONE WITH THIS!",
    "I'm calling EVERYONE! This needs answers!",
    "This is driving me CRAZY! Where are the sources?!",
    "I DEMAND better intel than this!",
    "No way! Not without verification! PULL THE FILES!"
  ]
};

// Jerri - Electric blue ball, mystical, meh vibe, lots of compliments
export const JERRI: BallPersonality = {
  id: 'jerri',
  name: 'Jerri',
  color: '#06b6d4',
  description: 'Mystical, neutral vibes, genuinely appreciates your questions',
  emoji: '🔵',
  responses: [
    "Wow, that's a really great question, honestly",
    "The answer is no, but like... really nice question though",
    "Yah... that's just... such a thoughtful thing to ask",
    "Meh, probably not, but genuinely appreciate the energy here",
    "No, but you asked it with such grace, you know?",
    "That's a really valid question, the answer's just... no",
    "I mean sure, that's cool, but also... nice try",
    "The vibe here is honestly immaculate, even if the answer is no",
    "You know what? The way you phrased that was really beautiful",
    "No to that, but yes to your overall question-asking abilities",
    "Meh on the actual answer, but the inquiry itself? Chef's kiss",
    "That's genuinely one of the better ways someone's asked me that",
    "I'm gonna say no, but like... I really respect the attempt",
    "Not particularly, but you've got great energy about it",
    "No, but honestly your question had me thinking for a second",
    "Ehhh, probably not, but that was really well constructed",
    "The answer: no. The question: inspired",
    "I feel like you don't get enough credit for asking stuff like this",
    "Not really, but I'm genuinely here for this whole vibe",
    "The cosmic answer is no, but your heart is in the right place"
  ]
};

// Fart responses - randomly triggered
export const FART_RESPONSES = [
  "Did you just fart? I'm not saying you farted, I'm just saying... I noticed.",
  "Was that you? Not accusing, just observing.",
  "I'm picking up on something... unclear if it was a question or a situation.",
  "That's not... was that part of the question? Asking for clarity.",
  "Something shifted just now and I felt it in my soul, man.",
  "No? Didn't think so, but the universe just spoke, didn't it?",
  "I'm just gonna pretend that was ethereal energy.",
  "That sound had layers. Definitely had layers.",
  "Sources say that happened. I didn't say it, sources did.",
  "Wow, that was... yah, that was really something."
];

export const PERSONALITIES = [BECKY, TIFF, LUNA, ZIGGY, ORACLE, SETH, JOE, JERRI];
